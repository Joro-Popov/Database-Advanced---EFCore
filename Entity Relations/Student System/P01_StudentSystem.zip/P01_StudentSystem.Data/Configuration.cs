﻿namespace P01_StudentSystem.Data
{
    public static class Configuration
    {
        public const string connectionString = @"Server=.;Database=StudentSystem;Integrated Security=true";
    }
}