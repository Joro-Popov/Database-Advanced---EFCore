﻿namespace Employees.App.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}