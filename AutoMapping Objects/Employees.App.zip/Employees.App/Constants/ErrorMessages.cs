﻿namespace Employees.App.Constants
{
    public static class ErrorMessages
    {
        public const string CommandDoesNotExists = "The entered command does not exists!";

        public const string EmployeeNotFound = "Employee Not Found";
    }
}