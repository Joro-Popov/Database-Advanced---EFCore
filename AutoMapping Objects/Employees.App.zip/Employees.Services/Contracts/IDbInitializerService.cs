﻿namespace Employees.Services.Contracts
{
    public interface IDbInitializerService
    {
        void InitializeDatabase();
    }
}