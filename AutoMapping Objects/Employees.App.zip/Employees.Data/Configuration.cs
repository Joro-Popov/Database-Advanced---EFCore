﻿namespace Employees.Data
{
    public static class Configuration
    {
        public const string CONNECTION_STRING = @"Server=DESKTOP-11B1NH5\SQLEXPRESS; Database=EmployeesDb; Integrated Security=true";
    }
}