﻿namespace Employees.Initializer
{
    using Employees.Initializer.Contracts;
    using Employees.Models;
    using System;
    using System.Collections.Generic;

    public class EmployeeInitializer : IEmployeeInitializer
    {
        public IEnumerable<Employee> GetEmployees()
        {
            var employees = new List<Employee>()
                {
                    new Employee { FirstName = "Georgi", LastName = "Popov", Salary = 1000.00m, Birthday = new DateTime(1993, 04, 04), Address = "Sofia, ul.Vitosha 15" },
                    new Employee { FirstName = "Steve", LastName = "Jobbsen", Salary = 1500.00m, Birthday = new DateTime(1981, 10, 03), Address = "Sofia, blvd.Stefan Stambolov 11" },
                    new Employee { FirstName = "Carl", LastName = "Kormac", Salary = 2000.00m, Birthday = new DateTime(1992, 01, 12), Address = "Sofia, ul.Hristo Botev 1" },
                    new Employee { FirstName = "Guy", LastName = "Gilbert", Salary = 3000.00m, Birthday = new DateTime(1976, 08, 24), Address = "Haskovo, ul.Madara 14" },
                    new Employee { FirstName = "Kevin", LastName = "Brown", Salary = 2400.00m, Birthday = new DateTime(1984, 11, 05), Address = "Haskovo, ul.Stara Planina 4" },
                    new Employee { FirstName = "Gail", LastName = "Erickson", Salary = 4000.00m, Birthday = new DateTime(1977, 09, 15), Address = "Plovdiv, ul.Ivan Vazov 3" },
                    new Employee { FirstName = "Terri", LastName = "Duff", Salary = 6000.00m, Birthday = new DateTime(1972, 02, 28), Address = "Plovdiv, ul.Odrin 23" },
                    new Employee { FirstName = "Susan", LastName = "Eaton", Salary = 3300.00m, Birthday = new DateTime(1992, 03, 18), Address = "Varna, ul.Morska 20" },
                    new Employee { FirstName = "Kim", LastName = "Rallas", Salary = 4500.00m, Birthday = new DateTime(1990, 12, 21), Address = "Varna, ul.Kraibrejna 3" },
                    new Employee { FirstName = "David", LastName = "Song", Salary = 3000.00m, Birthday = new DateTime(1989, 05, 11), Address = "Haskovo, ul.Orfei 6" },

                };

            return employees;
        }
    }
}
