﻿namespace Employees.Initializer
{
    using Employees.Data;
    using Employees.Initializer.Contracts;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class Initialize : IInitializer
    {
        private EmployeeInitializer employeeInitializer;

        public void Seed(EmployeesDbContext context)
        {
            this.InsertEmployees(context);
            this.employeeInitializer = new EmployeeInitializer();
        }

        private void InsertEmployees(EmployeesDbContext context)
        {
            var employees = this.employeeInitializer.GetEmployees();

            foreach (var e in employees)
            {
                if (this.IsValid(e))
                {
                    context.Employees.Add(e);
                }
            }
            context.SaveChanges();
        }

        private bool IsValid(object obj)
        {
            var validationContext = new ValidationContext(obj);
            var result = new List<ValidationResult>();

            return Validator.TryValidateObject(obj, validationContext, result, true);
        }
    }
}
