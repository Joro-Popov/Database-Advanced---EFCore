﻿namespace Employees.Initializer.Contracts
{
    using Employees.Data;

    public interface IInitializer
    {
        void Seed(EmployeesDbContext context);
    }
}
