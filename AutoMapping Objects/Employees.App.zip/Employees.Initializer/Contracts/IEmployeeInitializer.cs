﻿namespace Employees.Initializer.Contracts
{
    using Employees.Models;
    using System;
    using System.Collections.Generic;

    public interface IEmployeeInitializer
    {
        IEnumerable<Employee> GetEmployees();
    }
}
