﻿namespace _02.DatabaseFirst
{
    using System;

    public class Startup
    {
        public static void Main()
        {

        }
    }
}
