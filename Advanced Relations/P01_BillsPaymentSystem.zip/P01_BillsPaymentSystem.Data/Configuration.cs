﻿namespace P01_BillsPaymentSystem.Data
{
    public static class Configuration
    {
        public const string connectionString = @"Server=.;Database=BillsPaymentSystem;Integrated Security=true";
    }
}