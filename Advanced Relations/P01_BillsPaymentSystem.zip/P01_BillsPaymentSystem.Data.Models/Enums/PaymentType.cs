﻿namespace P01_BillsPaymentSystem.Data.Models.Enums
{
    public enum PaymentType
    {
        BankAccount = 1,
        CreditCard = 2
    }
}