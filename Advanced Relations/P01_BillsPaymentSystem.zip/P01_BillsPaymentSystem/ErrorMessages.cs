﻿namespace P01_BillsPaymentSystem
{
    public static class ErrorMessages
    {
        public const string userDoesNotExist = "User with Id {0} not found!";
    }
}