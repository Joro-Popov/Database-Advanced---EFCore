namespace FastFood.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=DESKTOP-11B1NH5\SQLEXPRESS;Database=FastFood;Trusted_Connection=True";
	}
}